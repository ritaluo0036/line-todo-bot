# LINE 待辦事項機器人 🤖

## 功能
- ➕ 新增待辦事項
- ✅ 標記完成
- 🗑 刪除事項
- 📅 每日摘要（完成率統計）

## 快速部署步驟

### 1. 申請 LINE Messaging API
1. 前往 https://developers.line.biz/
2. 登入 → Create Provider → Create Channel → Messaging API
3. 記下 **Channel Secret** 和 **Channel Access Token**

### 2. 部署到 Render.com（免費）
1. 註冊 https://render.com
2. New → Web Service → 上傳此程式碼（或連結 GitHub）
3. 設定環境變數：
   - `CHANNEL_SECRET` = 你的 Channel Secret
   - `CHANNEL_ACCESS_TOKEN` = 你的 Token
4. 取得網址，例如：`https://your-app.onrender.com`

### 3. 設定 Webhook
1. 回到 LINE Developers Console
2. Messaging API → Webhook URL 填入：
   `https://your-app.onrender.com/webhook`
3. 點「Verify」確認連線
4. 開啟「Use webhook」

### 4. 關閉自動回覆
在 LINE Official Account Manager 關閉預設自動回覆訊息

## 本地測試
```bash
npm install
CHANNEL_SECRET=xxx CHANNEL_ACCESS_TOKEN=yyy node index.js
# 用 ngrok 建立公開網址：ngrok http 3000
```

## 指令一覽
| 輸入 | 功能 |
|------|------|
| `+ 買早餐` | 新增待辦 |
| `完成 1` | 完成第1項 |
| `刪除 2` | 刪除第2項 |
| `清單` | 查看所有事項 |
| `今天` | 今日摘要 |
| `清除完成` | 清除已完成 |
| `說明` | 查看幫助 |
